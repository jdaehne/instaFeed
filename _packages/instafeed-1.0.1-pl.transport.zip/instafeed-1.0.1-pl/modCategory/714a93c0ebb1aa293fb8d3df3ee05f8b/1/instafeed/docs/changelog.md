Changelog for instaFeed

instaFeed 1.0.1
---------------------------------
+ Add remote Service

instaFeed 1.0.0
---------------------------------
+ Initial Version
