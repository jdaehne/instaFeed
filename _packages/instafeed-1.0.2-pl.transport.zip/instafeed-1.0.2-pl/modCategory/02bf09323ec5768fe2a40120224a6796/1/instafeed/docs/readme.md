
instaFeed

Author: Jan Dähne <https://www.quadro-system.de>
Copyright 2020

Official Documentation: https://www.quadro-system.de/modx-extras/instafeed/

Bugs and Feature Requests: https://github.com:jdaehne/instaFeed

Questions: http://forums.modx.com
