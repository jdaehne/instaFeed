<?php
/**
 * @package instafeed
 */
class InstaFeedItem extends xPDOSimpleObject {}
?>