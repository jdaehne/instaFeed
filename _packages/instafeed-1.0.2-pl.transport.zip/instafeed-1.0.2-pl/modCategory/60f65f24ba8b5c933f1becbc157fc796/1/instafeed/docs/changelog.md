Changelog for instaFeed

instaFeed 1.0.2
---------------------------------
+ Clear cache on import
+ Add published system setting
+ Add likes & comments property
+ update existing properties of an post

instaFeed 1.0.1
---------------------------------
+ Add remote Service

instaFeed 1.0.0
---------------------------------
+ Initial Version
