<?php
/**
 * Setting Lexicon Entries for instaFeed
 *
 * @package instaFeed
 * @subpackage lexicon
 */
$_lang['setting_instafeed.usernames'] = 'Usernames';
$_lang['setting_instafeed.usernames_desc'] = 'Comma separatet list of usernames to import.';
$_lang['setting_instafeed.image_path'] = 'Image-Path';
$_lang['setting_instafeed.image_path_desc'] = 'Path to store imported images.';
